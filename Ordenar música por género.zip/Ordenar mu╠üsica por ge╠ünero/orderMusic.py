import os
import shutil
import eyed3


origin = os.getcwd()+'/';
dirs = os.listdir(origin);

genreDirectories = [];

#CREA LOS DIRECTORIOS CON LOS NOMBRES DE LOS GENEROS
for audio in dirs:
    if(audio.endswith(".mp3")):
        audiofile = eyed3.load(audio);
        #print(audio)
        genre = str(audiofile.tag.genre);
        if(genre not in genreDirectories):
            genreDirectories.append(str(audiofile.tag.genre));

        '''if(audiofile.tag.artist not in genreDirectories):
            genreDirectories.append(str(audiofile.tag.artist));'''
            

#COLOCA LA MUSICA EN EL GENERO CORRESPONDIENTE
#SI LA MUSICA NO TIENE GENERO, LA COLOCA EN UNA CARPETA GENERICA
for audio in dirs:
    if(audio.endswith(".mp3")):
        audiofile = eyed3.load(audio);
        
        genre = str(audiofile.tag.genre);
        if(genre in genreDirectories):
            destination = origin + genre;
            if(not os.path.exists(destination)):
                os.makedirs(destination);
            shutil.move(audio, destination)
        '''
        genre = str(audiofile.tag.artist);
        if(genre in genreDirectories):
            if(not os.path.exists(origin+genre)):
                os.makedirs(origin+str(genre));
            shutil.move(audio, origin+genre)
        '''
